﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpenTK_winforms_z02
{
    class LightControl
    {
        public float[] valuesAmbient2 = new float[4];
        public float[] valuesDiffuse2 = new float[4];
        public float[] valuesSpecular2 = new float[4];
        public float[] valuesPosition2 = new float[4];

        private float[] valuesAmbientTemplate2 = new float[] { 0.1f, 0.1f, 0.1f, 1.0f };
        private float[] valuesDiffuseTemplate2 = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
        private float[] valuesSpecularTemplate2 = new float[] { 0.1f, 0.1f, 0.1f, 1.0f };
        private float[] valuesPositionTemplate2 = new float[] { 0.0f, 0.0f, 5.0f, 1.0f };

        bool lightON;
        public LightControl()
        {
            lightON = false;
            setTrackLight2Default();
        }

        public void setTrackLight2Default()
        {
            valuesPosition2[0] = 0;
            valuesPosition2[1] = 100;
            valuesPosition2[2] = 100;
        }

        public void valuesPositionXPlus()
        {
            valuesPosition2[0]++;
        }

        public void valuesPositionXMinus()
        {
            valuesPosition2[0]--;
        }

        public void valuesPositionYPlus()
        {
            valuesPosition2[1]++;
        }

        public void valuesPositionYMinus()
        {
            valuesPosition2[1]--;
        }

        public void valuesPositionZPlus()
        {
            valuesPosition2[2]++;
        }

        public void valuesPositionZMinus()
        {
            valuesPosition2[2]--;
        }

        public void setLight2Values()
        {
            for (int i = 0; i < valuesAmbientTemplate2.Length; i++)
            {
                valuesAmbient2[i] = valuesAmbientTemplate2[i];
            }
            for (int i = 0; i < valuesDiffuseTemplate2.Length; i++)
            {
                valuesDiffuse2[i] = valuesDiffuseTemplate2[i];
            }
            for (int i = 0; i < valuesPositionTemplate2.Length; i++)
            {
                valuesPosition2[i] = valuesPositionTemplate2[i];
            }
        }

        public void ToogleLight()
        {
            lightON = !lightON;
        }

        public void setLight(bool status)
        {
            lightON = status;
        }

        public bool isLightOn()
        {
            return lightON;
        }
    }
}
